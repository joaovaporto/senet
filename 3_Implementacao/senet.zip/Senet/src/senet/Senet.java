package senet;

import javax.swing.*;
import interfaceGrafica.InterfaceGrafica;

public class Senet {
	public static void main(String args[]) {
		InterfaceGrafica janela = new InterfaceGrafica("Senet");
		
	}
}
