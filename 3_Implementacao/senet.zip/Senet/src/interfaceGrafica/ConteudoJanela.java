package interfaceGrafica;

import javax.swing.*;

public class ConteudoJanela extends JPanel {
	private static final long serialVersionUID = 1L;	
}
