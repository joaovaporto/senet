package interfaceGrafica;

import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

public class InterfaceGrafica extends JFrame {
	private static final long serialVersionUID = 1L;
	
	public InterfaceGrafica(String nomeJanela) {
		super(nomeJanela);
		
		ConteudoJanela conteudoJanela = new ConteudoJanela();
		
		setSize(500, 500);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		carregarComponentesInternos();
		setContentPane(conteudoJanela);
		pack();
		setVisible(true);
	}
	
	public void carregarComponentesInternos() {
		JMenuBar menu = new JMenuBar();
		
		menu.setPreferredSize(new Dimension(500, 20));
		menu.setBackground(new Color(0,0,0));
		menu.setOpaque(true);
		
		setJMenuBar(menu);
	}
}
